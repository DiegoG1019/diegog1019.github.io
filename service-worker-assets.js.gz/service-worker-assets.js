self.assetsManifest = {
  "version": "TtGkOIur",
  "assets": [
    {
      "hash": "sha256-fR3jGbqCtXixVTrJrTJ5JKjUCT5TiNfjijOY5CWtC98=",
      "url": "CV-icon.svg"
    },
    {
      "hash": "sha256-DG6yH5YQuwDG0/EOMl/h879Olbtd9Jn9s71CrC2vzi8=",
      "url": "Diego CV - ENGLISH - DEC24.pdf"
    },
    {
      "hash": "sha256-pgIqJUg8iskHHbAsN4zXgiZNZUvwPxRbENb+9WS7LeE=",
      "url": "Diego CV - ESPAÑOL - DEC24.pdf"
    },
    {
      "hash": "sha256-2qu4TBnfXMPBRFOYKNyUCBRPxs7eYlCeVFypwodfqis=",
      "url": "DiegoG.WebTools.styles.css"
    },
    {
      "hash": "sha256-Z/I1339InDuOPqcxuznblrUyBaYIXu9HFBq2z/gXq8A=",
      "url": "_content/Blazored.Modal/Blazored.Modal.bundle.scp.css"
    },
    {
      "hash": "sha256-kA2z2nG9FrUdWS/uJrfB+pfqUujsR3MLSrJeQKsao/Q=",
      "url": "_content/Blazored.Modal/BlazoredModal.razor.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Y6pVrSnmzq2FCEnAkNngv+mtNlIljEmH3BEmGpr5jEQ=",
      "url": "_framework/Blazored.Modal.h7t7ava08f.wasm"
    },
    {
      "hash": "sha256-KqK8GwY2tzjuiVE8GFM9FfWCLOFWMU2RaD7qqiXtyXI=",
      "url": "_framework/DiegoG.WebTools.21vfvd8ra8.wasm"
    },
    {
      "hash": "sha256-gPUwGTHTe/sd4xmteeOSYd4a/J4deDy13pbwodSYfwc=",
      "url": "_framework/Markdig.82zk74d1io.wasm"
    },
    {
      "hash": "sha256-e5gBdHWMNmHXM51OkPYYSa1vyL6lvjEVn/uPkZaj+S4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.9f2pjrtyp1.wasm"
    },
    {
      "hash": "sha256-m+YQBuKldiBC30pXO7EvUXEBz/1G63oAkq9LXRjUQiM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r8m0mkd4zi.wasm"
    },
    {
      "hash": "sha256-9ETX5Oy1iBOsJ7I0I1Dqxm5YWBouinWmUm7DX+e+vwc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.kirzta6tuq.wasm"
    },
    {
      "hash": "sha256-bPg1RjkvGT1FA8c7MO8jDenCcUZjW7t1dGOD0mnhe4s=",
      "url": "_framework/Microsoft.AspNetCore.Components.olum8ra7r1.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-etJNRulPVegsFQmL8KZcFANEeBcqwDa7ROE1sX9SvlI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ur1um2lgj3.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-xqVuY/yz62qdo/388D86thEafDKJNd1pWtS5H09DwWc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6lsuqhbiqb.wasm"
    },
    {
      "hash": "sha256-9KuzeEULxB48uDxfCQmADlA/hCrH9yss6Jv1zf8uj28=",
      "url": "_framework/Microsoft.Extensions.Logging.ofkice3jaq.wasm"
    },
    {
      "hash": "sha256-ueRCTgiDMRoeRGmcGybrwwZ5wIj057NNM45ToRsvRcU=",
      "url": "_framework/Microsoft.Extensions.Options.x25gjdmbax.wasm"
    },
    {
      "hash": "sha256-GOr7jc/eCieZrQYoXRn79eLSsesIfFB55wQZIVTSNIY=",
      "url": "_framework/Microsoft.Extensions.Primitives.4dxofymb0o.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-iZGdoSQHD1PU7bXZFZu5qQCo4LYV5+W54+dZpxtPchE=",
      "url": "_framework/Microsoft.JSInterop.ngmvv3s7g6.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-j5wfq2d8RPMkWUoLgOF6BYEGBOzy68QJpT8LU7LMDU8=",
      "url": "_framework/SixLabors.ImageSharp.Drawing.jbfs0sbj9h.wasm"
    },
    {
      "hash": "sha256-77nA5mn/uzCwqe/1H51g+20P4qRfvX9eAcTtBzfBEnE=",
      "url": "_framework/SixLabors.ImageSharp.d1axdmx9vo.wasm"
    },
    {
      "hash": "sha256-vQl55Jds2rFwytBZE0Lv0RIWfmA7hRgBTko0vASaXa8=",
      "url": "_framework/System.Collections.Concurrent.5myur1uygv.wasm"
    },
    {
      "hash": "sha256-WgxmAS5VoBNvgTviU1i6XdI9SXdf0cwpNmi5S4VKdZY=",
      "url": "_framework/System.Collections.Immutable.qoyrcidt62.wasm"
    },
    {
      "hash": "sha256-/EKw6AnuEFZq6ur2mRFE3Dh+MEjl6xRLIvYt7Sh/keo=",
      "url": "_framework/System.Collections.NonGeneric.w3nszrltmj.wasm"
    },
    {
      "hash": "sha256-+1WAfC5z4WPEyRVnWnXBFFcG9JDuKTCxmbbzsuKK7NE=",
      "url": "_framework/System.Collections.Specialized.pnfjk8yclv.wasm"
    },
    {
      "hash": "sha256-HVoSC0ziYzxBrvHzFMYm8ns10eNXHzEetG2Y8lw7S90=",
      "url": "_framework/System.Collections.t8a9ugqw5j.wasm"
    },
    {
      "hash": "sha256-fbqwpUqcYvdF9CnMbx4Vg8yf6niUh5rA3yMQLGLrnNg=",
      "url": "_framework/System.ComponentModel.Primitives.lmdyd1bbqh.wasm"
    },
    {
      "hash": "sha256-sXAY9FcTneJUKzLUZw9VvnnjtxSirPiw8phKUgOqWig=",
      "url": "_framework/System.ComponentModel.TypeConverter.hgmckc73jy.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-dQ8sy2Fkm3iqiPIiFpaxnulSKP/l4kS/T+CjZ9cujiA=",
      "url": "_framework/System.Console.r46mogd4ui.wasm"
    },
    {
      "hash": "sha256-W+vYUclEVN7uT3jxBtAHZrYoVhQy//5KjUc7THren94=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.t6np3otb78.wasm"
    },
    {
      "hash": "sha256-LSMH2OVGolpAOITHT2KfLjgMKMvRa6JJuRRhKzgUB+8=",
      "url": "_framework/System.Drawing.9tlrgr2oa7.wasm"
    },
    {
      "hash": "sha256-ESoHeWfEMMb8EmvP0Dd6JbHHWN0YawUJTbj9Loj5tPM=",
      "url": "_framework/System.Drawing.Primitives.j7e450pwdi.wasm"
    },
    {
      "hash": "sha256-0EHYh6uqVTvM+J+Ph963ylzDY5E6WyWMvUKfJ3mxaF8=",
      "url": "_framework/System.IO.Compression.wsqiqbgc3v.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-2Imyo50kE0uBYJyVkJEBH7WXsEPa5z0pcDHRWznNO9A=",
      "url": "_framework/System.Linq.Expressions.svb45rvchv.wasm"
    },
    {
      "hash": "sha256-wh1m1pi1qKxecyAW0d1y93I1oZiKorI3iGU6c2gCu4E=",
      "url": "_framework/System.Linq.ameng9iqmh.wasm"
    },
    {
      "hash": "sha256-gGn6F5ClWegL+CBrzQr4QK26ILXBfpxaj5oaB55CFF4=",
      "url": "_framework/System.Memory.g42f14wylk.wasm"
    },
    {
      "hash": "sha256-OOOCLaGWXpNcX7W7ZKUGun+aow6iURFF34fZb+u5uu8=",
      "url": "_framework/System.Net.Http.Json.gya3llq5ga.wasm"
    },
    {
      "hash": "sha256-F4LlWmjYbcD0uRXR0zuMZlcBfZhneqp5erx25/VpYdA=",
      "url": "_framework/System.Net.Http.tf7h2r7td6.wasm"
    },
    {
      "hash": "sha256-ZeNwhIn7WkoYVZst+ETUsP6vnhBj3XKvQJwcdhz+yVM=",
      "url": "_framework/System.Net.Primitives.58k8z28kfs.wasm"
    },
    {
      "hash": "sha256-fEJeCg2bC//l/r+psiio8qa8BDbJTuP0vzE8WMZHNTY=",
      "url": "_framework/System.ObjectModel.gx131km33y.wasm"
    },
    {
      "hash": "sha256-dlK9zLtlpBlyA61+i6d8sff5sxygVex9qt+3wlOAom0=",
      "url": "_framework/System.Private.CoreLib.q72ls2z5ls.wasm"
    },
    {
      "hash": "sha256-4sOAQXlwV1x+5Q/F34SIicR/sY2hi1PdNhH+L3SpbsM=",
      "url": "_framework/System.Private.Uri.i4cqcme6o0.wasm"
    },
    {
      "hash": "sha256-sLeKTjjk1KjQiqejKInds3+0PYWznIJ6hrj/ylbmWTs=",
      "url": "_framework/System.Private.Xml.044y333c0a.wasm"
    },
    {
      "hash": "sha256-njZ2CekSFP7au2YgpcEwCrpQFk/i8hurkjo1LcWaqxc=",
      "url": "_framework/System.Private.Xml.Linq.ehjn3lrsfa.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-CcFw61Moc8jk6fUvVpsiFKoUl/dD+5ah6KM4lchwX/o=",
      "url": "_framework/System.Runtime.InteropServices.jlvodb9z1c.wasm"
    },
    {
      "hash": "sha256-M35P3nCOrpdnebWXYyoUi/j7p9cJl6cJTFWAjZomh6s=",
      "url": "_framework/System.Runtime.Serialization.Primitives.nfoq0oaefk.wasm"
    },
    {
      "hash": "sha256-2FzBb/4YTyQixaw9wKkrTsKFpnyqtzEdMcDPBMqgMYE=",
      "url": "_framework/System.Runtime.srfw9r97hu.wasm"
    },
    {
      "hash": "sha256-bjTnvPXhmcHRPe0Wk8McV9nfAfu+X5l2mXB4n8tCEcU=",
      "url": "_framework/System.Security.Cryptography.i0war05rtp.wasm"
    },
    {
      "hash": "sha256-nPlaMEmy5Gr7XxS2TtOaL89w5TO5YnWEQrpMu6i4NNE=",
      "url": "_framework/System.Text.Encoding.CodePages.kobdawotg8.wasm"
    },
    {
      "hash": "sha256-pdi8rUtz97K7+q5y/AgnLY20C4reLdWB+WoFACY2+qM=",
      "url": "_framework/System.Text.Encodings.Web.n5x6mx40rp.wasm"
    },
    {
      "hash": "sha256-QEiPO1GRPd63fKgCzC4iJAzuFf4cha0ZRlmWeBxB8zQ=",
      "url": "_framework/System.Text.Json.oieddgoxoe.wasm"
    },
    {
      "hash": "sha256-rnfSpqFd2w2tDE19IIGV6T8IAspJKSDHsVS2YlRI2mQ=",
      "url": "_framework/System.Text.RegularExpressions.e1etgf7ms8.wasm"
    },
    {
      "hash": "sha256-8mVK9OUYaMUoJkGYuZPSnW5tDnUp9uMSsqsVsEFCgUI=",
      "url": "_framework/System.Threading.Tasks.Parallel.a6ljsitmp6.wasm"
    },
    {
      "hash": "sha256-wjthzJhHdr+u//LUOcas8X4kETqxfUWBzxyg9k9ce1I=",
      "url": "_framework/System.Threading.ax55v6kmii.wasm"
    },
    {
      "hash": "sha256-YIafJK5Imy94JBPwVefO7XwTTr6Wrdt8J4cuwLfDjV8=",
      "url": "_framework/System.Xml.Linq.omrm9aobo0.wasm"
    },
    {
      "hash": "sha256-C9doQ2kRXh07SHpwXE9w/h/DVfCgnaRhM5xsk3YtQzU=",
      "url": "_framework/System.Xml.XDocument.bcdec8rl4s.wasm"
    },
    {
      "hash": "sha256-JR9uHwZeWzGLHbZhs4tvobv0QX0mykH6Dw/KbNqFbCA=",
      "url": "_framework/System.v3da086c8u.wasm"
    },
    {
      "hash": "sha256-1UwXeeoQzig+2cCJv+l/TsxODawWmhe3lkBTuYzmSLI=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-KIdOjTgqwnRPrs8E/UU8iLB9en7vECQ7k7cYFlvwVKQ=",
      "url": "_framework/dotnet.native.8cvul2x4bx.js"
    },
    {
      "hash": "sha256-YbSB1/9Ktd1raw9qZF1fEEuXfCYNk6uslNVgf7Zbgl4=",
      "url": "_framework/dotnet.native.dtkkqlcmr8.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-H5VHSIUJx0i9F63+V5Ry3+gWlMBEzsXSxBRV073apD0=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-exc9c7hTV9Cb+BfpfOnzSGiWhJQKk7BQsHi5jd7ZSzo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-W7ak/EGNO8IPTZEi16+5tI2xfeN8N3lFJLAiHA1H08E=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ss3r+BvJXpL5Qr6jhPQMRnqZV/AIjR7HgcvvrPKwQBw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-h5KyEjypfLUc0eJEFykuY82A7M4fHWTtoc82u3Gy1rg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Tx7yA40PfJ+TqdDnvsSixbEWfqq1E1T/C9W8u5RRU8E=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-0/61oxM4YQby9pLbfu1U1mBZWm7PUjKU9yc8Z1xBMKQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-EyW2KiwsyOfqLLehwJ6tDKhFUNeXILxbENf+uVUFyxY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Mz8HMThzol5EonvCxgnhLTY0+eiDcpyQ18rn647ZlSE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Nblnm9Fxa4q/m+kgbf2+9nvAbHdKuvCZpVj2iVBTGfQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-vSxd/IUU6SwSA5yx5lW38+boiLASbenB7zX9Rurh5AI=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-53VXXdN/GgBwqLtwN/EiiwQ7zKA2RzWry5na6Cu+BMA=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-a/Gbm1CCVHZJnJDEjuRi4DgflxwFuRQn7kzplj+n4iI=",
      "url": "professional-pic.jpg"
    }
  ]
};
