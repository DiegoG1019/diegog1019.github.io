self.assetsManifest = {
  "version": "Xc2OAScF",
  "assets": [
    {
      "hash": "sha256-fR3jGbqCtXixVTrJrTJ5JKjUCT5TiNfjijOY5CWtC98=",
      "url": "CV-icon.svg"
    },
    {
      "hash": "sha256-DG6yH5YQuwDG0/EOMl/h879Olbtd9Jn9s71CrC2vzi8=",
      "url": "Diego CV - ENGLISH - DEC24.pdf"
    },
    {
      "hash": "sha256-pgIqJUg8iskHHbAsN4zXgiZNZUvwPxRbENb+9WS7LeE=",
      "url": "Diego CV - ESPAÑOL - DEC24.pdf"
    },
    {
      "hash": "sha256-N08mpZA8DNx89WTd6RmAsIyKNXxEPVKUgoChyGj4aoo=",
      "url": "DiegoG.WebTools.styles.css"
    },
    {
      "hash": "sha256-Z/I1339InDuOPqcxuznblrUyBaYIXu9HFBq2z/gXq8A=",
      "url": "_content/Blazored.Modal/Blazored.Modal.bundle.scp.css"
    },
    {
      "hash": "sha256-kA2z2nG9FrUdWS/uJrfB+pfqUujsR3MLSrJeQKsao/Q=",
      "url": "_content/Blazored.Modal/BlazoredModal.razor.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Y6pVrSnmzq2FCEnAkNngv+mtNlIljEmH3BEmGpr5jEQ=",
      "url": "_framework/Blazored.Modal.h7t7ava08f.wasm"
    },
    {
      "hash": "sha256-R13GOczVxZrkm5vTIYnFZJy5JS1AC9LUi711GmwY1PQ=",
      "url": "_framework/DiegoG.WebTools.5xtpbp9z9k.wasm"
    },
    {
      "hash": "sha256-gPUwGTHTe/sd4xmteeOSYd4a/J4deDy13pbwodSYfwc=",
      "url": "_framework/Markdig.82zk74d1io.wasm"
    },
    {
      "hash": "sha256-zTUhdMjdNP85oj7nfnJ/POVH46fVhLEBRYwhAwErYKQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.1z66laz4oy.wasm"
    },
    {
      "hash": "sha256-e5gBdHWMNmHXM51OkPYYSa1vyL6lvjEVn/uPkZaj+S4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.9f2pjrtyp1.wasm"
    },
    {
      "hash": "sha256-m+YQBuKldiBC30pXO7EvUXEBz/1G63oAkq9LXRjUQiM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r8m0mkd4zi.wasm"
    },
    {
      "hash": "sha256-9ETX5Oy1iBOsJ7I0I1Dqxm5YWBouinWmUm7DX+e+vwc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.kirzta6tuq.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-1G9JoMIJCufPsSAkdCkWVd4TbodnlVL0ucFkYsl2FqE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.odgt8suz8n.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-xqVuY/yz62qdo/388D86thEafDKJNd1pWtS5H09DwWc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6lsuqhbiqb.wasm"
    },
    {
      "hash": "sha256-9KuzeEULxB48uDxfCQmADlA/hCrH9yss6Jv1zf8uj28=",
      "url": "_framework/Microsoft.Extensions.Logging.ofkice3jaq.wasm"
    },
    {
      "hash": "sha256-ueRCTgiDMRoeRGmcGybrwwZ5wIj057NNM45ToRsvRcU=",
      "url": "_framework/Microsoft.Extensions.Options.x25gjdmbax.wasm"
    },
    {
      "hash": "sha256-GOr7jc/eCieZrQYoXRn79eLSsesIfFB55wQZIVTSNIY=",
      "url": "_framework/Microsoft.Extensions.Primitives.4dxofymb0o.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-iZGdoSQHD1PU7bXZFZu5qQCo4LYV5+W54+dZpxtPchE=",
      "url": "_framework/Microsoft.JSInterop.ngmvv3s7g6.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-j5wfq2d8RPMkWUoLgOF6BYEGBOzy68QJpT8LU7LMDU8=",
      "url": "_framework/SixLabors.ImageSharp.Drawing.jbfs0sbj9h.wasm"
    },
    {
      "hash": "sha256-77nA5mn/uzCwqe/1H51g+20P4qRfvX9eAcTtBzfBEnE=",
      "url": "_framework/SixLabors.ImageSharp.d1axdmx9vo.wasm"
    },
    {
      "hash": "sha256-/DwgUAf4CXDxzzobv4W35Yqe+ht+n1+JTOzofWV1aQI=",
      "url": "_framework/System.Collections.Concurrent.40c5r3puwp.wasm"
    },
    {
      "hash": "sha256-r667flpAh/bGxfL8ZeuoDUo9T6zBxZ/iuX9jdZ9RPuo=",
      "url": "_framework/System.Collections.Immutable.pqt77qvvuv.wasm"
    },
    {
      "hash": "sha256-/Czfyaiw8VxsgJODWNwy0ICOuBQHkWikJ7sGk9qM9jU=",
      "url": "_framework/System.Collections.NonGeneric.wrlr6g0ynv.wasm"
    },
    {
      "hash": "sha256-NR1z2hyU8sMkumbXVHOWc/eRD6T46CQoGQbMJLhKc94=",
      "url": "_framework/System.Collections.Specialized.5sseg5tudv.wasm"
    },
    {
      "hash": "sha256-JhBOPmHi+l8elMvkT4taFGENH6jWsdoNJ8Umk9fgWmk=",
      "url": "_framework/System.Collections.abdfrxoufb.wasm"
    },
    {
      "hash": "sha256-IrJW+x8EXCpP9VMofY6ehtMSOokXtqC4/H77EqHBvDc=",
      "url": "_framework/System.ComponentModel.Primitives.q630y8a6mm.wasm"
    },
    {
      "hash": "sha256-//FGn+3U12/wo8VnvGTDk2G3jOHo7cvKS3SwVwOs3Zk=",
      "url": "_framework/System.ComponentModel.TypeConverter.dpjp6qfawy.wasm"
    },
    {
      "hash": "sha256-QD1DVHIO0+qjM/srw8UNWViolwFgILe7Ow44CMx7z8A=",
      "url": "_framework/System.ComponentModel.oqggmdaxu6.wasm"
    },
    {
      "hash": "sha256-IbJJ9T7mgqcb/RWgawUAz1a4kyuANa4NUpd0t2KZAGc=",
      "url": "_framework/System.Console.hojia54vdx.wasm"
    },
    {
      "hash": "sha256-+veuX8DWoEb0kYxNq0haS8KcLMGlABRM7u0HEWbduyM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.2p4h6car0p.wasm"
    },
    {
      "hash": "sha256-2Aks09WhVjpPXFa5/YSPuLXbPjc/R9WSP1E/7HUj9Nc=",
      "url": "_framework/System.Drawing.Primitives.czu4kk3ktj.wasm"
    },
    {
      "hash": "sha256-baA0Rs5rXFIK81FazI8Nd5eG/F3kAMqJ1LV0bLi45PY=",
      "url": "_framework/System.Drawing.xbwbk1ny24.wasm"
    },
    {
      "hash": "sha256-oxULnqMoDBdl1uwEC2ibH3nVk/PKVxR/bAjIQrbYtVo=",
      "url": "_framework/System.IO.Compression.b68pwk3o9l.wasm"
    },
    {
      "hash": "sha256-LHmn3NZ0cYl/sD4s/EA26iSAYqDCycxgYdwt6suIKLM=",
      "url": "_framework/System.IO.Pipelines.wfn2m8uvna.wasm"
    },
    {
      "hash": "sha256-mw30WGUtUV9mEnZLJCy+/2O4FvdgG+++a+x7mnO/A+k=",
      "url": "_framework/System.Linq.Expressions.r4jju6bj5b.wasm"
    },
    {
      "hash": "sha256-rEy3tedwINQsDVD85m4P2xYwPkyt+PYLVtvWmXCW8UY=",
      "url": "_framework/System.Linq.sks08x9kuu.wasm"
    },
    {
      "hash": "sha256-nrtDk38ymV76zVq1y6ZJsylV8/lnTqWpWMjRsTjFfMY=",
      "url": "_framework/System.Memory.m7pn9n86ux.wasm"
    },
    {
      "hash": "sha256-N0ywRwbeMZVWE81dZJ1aUBu8TIoFq4uKa5cjar5Zb2M=",
      "url": "_framework/System.Net.Http.Json.nge03cvicx.wasm"
    },
    {
      "hash": "sha256-BZt+6OSs6C38cE/8XKoGs/3yli4NuFy8CPrsJZHGE+Q=",
      "url": "_framework/System.Net.Http.r80ng977er.wasm"
    },
    {
      "hash": "sha256-UWz8Xc3aMOOTtjyxXS9iphkcGf6l5buhiMUj+mgIxRU=",
      "url": "_framework/System.Net.Primitives.neyihtxzev.wasm"
    },
    {
      "hash": "sha256-2AWu7cR0xD2kF2PSXB6gDPoikLc+JUkTo3C6ZKAkNgQ=",
      "url": "_framework/System.ObjectModel.41wwkjhz5i.wasm"
    },
    {
      "hash": "sha256-9gAkPSxHFqEX6xRiY/lIIFUEX7xT3KSIdSA0g5aQdgg=",
      "url": "_framework/System.Private.CoreLib.yp9zdivd6r.wasm"
    },
    {
      "hash": "sha256-Xk3VgFsms04Q/+2/DgM40kMeUHmYiK7WUuYh1eCfB9o=",
      "url": "_framework/System.Private.Uri.e8v1djebla.wasm"
    },
    {
      "hash": "sha256-w82eHnsm2bTZ4FW/8A9rF8dntTuIo1d9HeOUlsihBL4=",
      "url": "_framework/System.Private.Xml.954dkq2qux.wasm"
    },
    {
      "hash": "sha256-ilJYHqsLLnx1qPOqA0qCg8HQk0M4bV+yQuTp3FzJCFo=",
      "url": "_framework/System.Private.Xml.Linq.uvl3hovzxz.wasm"
    },
    {
      "hash": "sha256-xoGVi6yRyxkzsRPcNgy0BEvx2DH0EZjL48BuDvNVjHY=",
      "url": "_framework/System.Runtime.InteropServices.2p0x4z5nc9.wasm"
    },
    {
      "hash": "sha256-cTDlU0sLp3hCmTKUK2AVqrlAjuFjQveVBhCUZiIdUkc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lnedh9fxsl.wasm"
    },
    {
      "hash": "sha256-JglRMh8993SiSt5YUvOBMzKRb/DGgA5GbJGBT9c2RQk=",
      "url": "_framework/System.Runtime.Serialization.Primitives.a01j3ygjje.wasm"
    },
    {
      "hash": "sha256-ZfPMdcR2SKTgdBbNZyC9Db5VEf/nsb0U3KFNEeCT+LE=",
      "url": "_framework/System.Runtime.b8n89bn3so.wasm"
    },
    {
      "hash": "sha256-fLrqEqgOhxMVmox/Oy7L/P3p7Icd8CGQ86M/yjOhjsA=",
      "url": "_framework/System.Security.Cryptography.gjcgztcbk1.wasm"
    },
    {
      "hash": "sha256-MNY6TFoW4XyzVyYfo2W5guKXJPphheBFTTZE+2I2WVo=",
      "url": "_framework/System.Text.Encoding.CodePages.oapv80pwdt.wasm"
    },
    {
      "hash": "sha256-5roL5hgDxtpOyji6xusmx3evKf+54YuFbIJpejfq0XQ=",
      "url": "_framework/System.Text.Encodings.Web.q7l6i2z1r3.wasm"
    },
    {
      "hash": "sha256-hMmtoC5kRsUqW0pW+uGX3ypBB3RXkZglxGUPoLWxL7s=",
      "url": "_framework/System.Text.Json.whs5uj6pcd.wasm"
    },
    {
      "hash": "sha256-TbFHSoLfFHuTamhenPYvzxn56FGYU2YnKNmMinph/yE=",
      "url": "_framework/System.Text.RegularExpressions.r2dyocpisp.wasm"
    },
    {
      "hash": "sha256-IsPWnOchrZKpmpVfrX7dLNAfMUmQOWeUxcumB2LgIUQ=",
      "url": "_framework/System.Threading.Tasks.Parallel.i7dwqm8ph4.wasm"
    },
    {
      "hash": "sha256-EXQRreBZRNntUAqAPXfCua2HzOpgyuiRJi1vC8p3/zI=",
      "url": "_framework/System.Threading.jn6105gyvd.wasm"
    },
    {
      "hash": "sha256-wwxsYRpXsPfLkFVXXX9uditc29XXKjAFv10/9OYAhf8=",
      "url": "_framework/System.Xml.Linq.hvxjxkvtb2.wasm"
    },
    {
      "hash": "sha256-8iJ0awg0+x18I0ncR/TywqyPlwvLvfssiVm8X9ErqhE=",
      "url": "_framework/System.Xml.XDocument.u95h2n7mh7.wasm"
    },
    {
      "hash": "sha256-/Imz/Enqa2AZc4T3k/CqtsM6674KRN9OUtvK4Nokhew=",
      "url": "_framework/System.wznexm8bk2.wasm"
    },
    {
      "hash": "sha256-smEmYumO15LzwTxagGPJJnbu2if1bjQhK9vEbt/IzR4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3MHpnImjcdbndre7BEBFmcZQ61mhKqldc9b5Bpp44Xo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-2c86imtxq4CFAycbliFgJZFKqgZL+Yxnq09Ca9Oa3Ms=",
      "url": "_framework/dotnet.native.7gq1obdgc1.wasm"
    },
    {
      "hash": "sha256-e8yPPAIutQrVipU5SyixzNeHMyQJZ21IPy3EZ8vn6v4=",
      "url": "_framework/dotnet.native.9zlpwida0q.js"
    },
    {
      "hash": "sha256-x+PnWU47EIr/zL3xxqIUMDJi/dy5904TVGunDqCvjIY=",
      "url": "_framework/dotnet.runtime.593bvuk5yc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-9U9AtkW4uGzJICOOjiQ3vtbZRP3xuRpu9eTtSImMmpg=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-exc9c7hTV9Cb+BfpfOnzSGiWhJQKk7BQsHi5jd7ZSzo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-W7ak/EGNO8IPTZEi16+5tI2xfeN8N3lFJLAiHA1H08E=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ss3r+BvJXpL5Qr6jhPQMRnqZV/AIjR7HgcvvrPKwQBw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-h5KyEjypfLUc0eJEFykuY82A7M4fHWTtoc82u3Gy1rg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Tx7yA40PfJ+TqdDnvsSixbEWfqq1E1T/C9W8u5RRU8E=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-0/61oxM4YQby9pLbfu1U1mBZWm7PUjKU9yc8Z1xBMKQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-EyW2KiwsyOfqLLehwJ6tDKhFUNeXILxbENf+uVUFyxY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Mz8HMThzol5EonvCxgnhLTY0+eiDcpyQ18rn647ZlSE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Nblnm9Fxa4q/m+kgbf2+9nvAbHdKuvCZpVj2iVBTGfQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-vSxd/IUU6SwSA5yx5lW38+boiLASbenB7zX9Rurh5AI=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-53VXXdN/GgBwqLtwN/EiiwQ7zKA2RzWry5na6Cu+BMA=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-a/Gbm1CCVHZJnJDEjuRi4DgflxwFuRQn7kzplj+n4iI=",
      "url": "professional-pic.jpg"
    }
  ]
};
