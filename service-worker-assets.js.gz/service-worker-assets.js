self.assetsManifest = {
  "version": "kX1t8LIm",
  "assets": [
    {
      "hash": "sha256-fR3jGbqCtXixVTrJrTJ5JKjUCT5TiNfjijOY5CWtC98=",
      "url": "CV-icon.svg"
    },
    {
      "hash": "sha256-DG6yH5YQuwDG0/EOMl/h879Olbtd9Jn9s71CrC2vzi8=",
      "url": "Diego CV - ENGLISH - DEC24.pdf"
    },
    {
      "hash": "sha256-pgIqJUg8iskHHbAsN4zXgiZNZUvwPxRbENb+9WS7LeE=",
      "url": "Diego CV - ESPAÑOL - DEC24.pdf"
    },
    {
      "hash": "sha256-BpYKM/oeQZE7UjA75bwx1BvyKBgUGH7cOvZDRS76BEo=",
      "url": "DiegoG.WebTools.styles.css"
    },
    {
      "hash": "sha256-Gzadz9z1FhL1Ak27FywvCxdMPikQNidMAnpuPRGccro=",
      "url": "_framework/DiegoG.WebTools.xxaqoqpbjr.wasm"
    },
    {
      "hash": "sha256-gPUwGTHTe/sd4xmteeOSYd4a/J4deDy13pbwodSYfwc=",
      "url": "_framework/Markdig.82zk74d1io.wasm"
    },
    {
      "hash": "sha256-cfqmEQGwtCMx8Lw+1Ex6JEqXpj7L3mm1hCOpgYsrdIE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.xo33xxyfys.wasm"
    },
    {
      "hash": "sha256-IchouBpswxjs82q7Hm2zmBvnyRZPfrqAQmYL/8UQVMU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7qzco4lkrq.wasm"
    },
    {
      "hash": "sha256-sbPEkBmzDVjx11ZQ92O/c9QC4jkne/WbXg0vWWvxU0k=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.jzx12ergrf.wasm"
    },
    {
      "hash": "sha256-DNWZ1sZTeqlpKKXj+krJL6umfRuJyERvkJtCqAklWW8=",
      "url": "_framework/Microsoft.AspNetCore.Components.oh9glf7gv2.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-wyf8Vo6UgYf0nBwXNCaCuIFe0U/I9p7vR4d7VpKg8fQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.t8c9edx0n1.wasm"
    },
    {
      "hash": "sha256-cn2ehNN7MlrB+/r/w7Nrme8kvXYsmtAFzDsmINAc+oc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.2bo2r0y66w.wasm"
    },
    {
      "hash": "sha256-foWTa1hrk6E7QaS6gv1RaIMX6vCgk7PIb4YEFI7zL9I=",
      "url": "_framework/Microsoft.Extensions.Logging.mqkel42d1f.wasm"
    },
    {
      "hash": "sha256-aghFR5ix2EFcXsXxIjilRm2GirVLMF7NAkzXIR0Y9JY=",
      "url": "_framework/Microsoft.Extensions.Options.er9kaksr7l.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-LuYfR4a5fwfclUwXPnTjZGpINIjF23AhCZmTFWP2xbQ=",
      "url": "_framework/Microsoft.JSInterop.iknej2zdh8.wasm"
    },
    {
      "hash": "sha256-ayRMl7l1GF4h65kNE0bKJ4lrGPZxmR+OkvPUFrQ11oU=",
      "url": "_framework/QRCoder.jqr4n2c9hc.wasm"
    },
    {
      "hash": "sha256-j5wfq2d8RPMkWUoLgOF6BYEGBOzy68QJpT8LU7LMDU8=",
      "url": "_framework/SixLabors.ImageSharp.Drawing.jbfs0sbj9h.wasm"
    },
    {
      "hash": "sha256-Em5nLWWkar7G0zZCk2Tw5GDHMrxenGfpxJyRmwrB0ek=",
      "url": "_framework/SixLabors.ImageSharp.mqzg1eyblr.wasm"
    },
    {
      "hash": "sha256-4SwkzWOR8xnWevuzYc1mmTKbN9SgHqe1FBoEgmEDOuE=",
      "url": "_framework/System.Collections.Concurrent.vkreom28gw.wasm"
    },
    {
      "hash": "sha256-M4hrHQJ8gbD9dTuw/NpW6tK6d7eOBl9ALv1XR9oZHSQ=",
      "url": "_framework/System.Collections.Immutable.h7g72yqmth.wasm"
    },
    {
      "hash": "sha256-twy9+jx8tM/46TSyxk6zTKQpqgYS/FJI84RqRGcGu1w=",
      "url": "_framework/System.Collections.NonGeneric.xawnctdcvj.wasm"
    },
    {
      "hash": "sha256-O07OV5IRptzHnOhxKlUaqhRdPrOFEw0lfSHvsn+wz7I=",
      "url": "_framework/System.Collections.Specialized.hdmqukthmj.wasm"
    },
    {
      "hash": "sha256-Ri+AePKdFJGyvUixiMQ/Tx/IGJYiJaX6r/eHvn23M+M=",
      "url": "_framework/System.Collections.ya30w8svf2.wasm"
    },
    {
      "hash": "sha256-IV9Cvb3ydQ2bQrS/qfyZE63/FtCBLJJS/A79FvPd2vM=",
      "url": "_framework/System.ComponentModel.3zv8xfb1e2.wasm"
    },
    {
      "hash": "sha256-L9ydyPp9o95PgIx9wzJsnuZNoh01soD530nyU7fg1ws=",
      "url": "_framework/System.ComponentModel.Primitives.zbwy0db05o.wasm"
    },
    {
      "hash": "sha256-eAQGc+zI4dZ6h1nkJW7aGzoNeqaRySdQrRzqs8m/OG4=",
      "url": "_framework/System.ComponentModel.TypeConverter.0yrcgn28yj.wasm"
    },
    {
      "hash": "sha256-HS+73HLzk8T27otABnhSUdeZD5EkolCDe3czKU/I/O8=",
      "url": "_framework/System.Console.fts4qr0nom.wasm"
    },
    {
      "hash": "sha256-mPXh53MMYsZTp+L7rAZoMo6EKUtuxL5dxuVfdNwpmMs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.crwz9broo6.wasm"
    },
    {
      "hash": "sha256-LjsgLYBaw95BFy+iUY264ro+Ebs7Vv8dgUi46pugBts=",
      "url": "_framework/System.Drawing.Primitives.ivk21hyj1o.wasm"
    },
    {
      "hash": "sha256-Nm+8NY9QuYQFIhkwkQUhVsR1WenB7vm6Rs2fdDZJtl0=",
      "url": "_framework/System.Drawing.u6cy9lqhsq.wasm"
    },
    {
      "hash": "sha256-vuZ4RTcOsrJ9qq0ixxmjoWzGpo/ODbstueKpSQm/JMo=",
      "url": "_framework/System.IO.Compression.ybpaoccvgj.wasm"
    },
    {
      "hash": "sha256-A/zbBw0DrouhwRThvr8F1IcKa5ApGW5BE01HoHB7igA=",
      "url": "_framework/System.IO.Pipelines.twix2pm6u4.wasm"
    },
    {
      "hash": "sha256-B69mUggmwW3tvvGjcgIz3XqtOqTQuY9uuiAV/wt2fpc=",
      "url": "_framework/System.Linq.Expressions.psj3q0j5va.wasm"
    },
    {
      "hash": "sha256-VShwvg1vZqOYgTNgZd0eM9fH3UZk2CzfPgGWz3sje10=",
      "url": "_framework/System.Linq.npxcmzy9a5.wasm"
    },
    {
      "hash": "sha256-ELv1WOW2IxWs5ZJi58aQy3wvEg4rsf9HjqSH90jTz30=",
      "url": "_framework/System.Memory.ww9v9ea3r3.wasm"
    },
    {
      "hash": "sha256-KV8OlZSozPkJbP3y6nIm5Yge+wSY/Ctv1M/GpcHc4eM=",
      "url": "_framework/System.Net.Http.Json.9k5o99c0yo.wasm"
    },
    {
      "hash": "sha256-v7o4PXMKYJXd4LnRqI+HTDkXen367rnpSE6HwUwFj0s=",
      "url": "_framework/System.Net.Http.t1omutf35o.wasm"
    },
    {
      "hash": "sha256-Veph07He3TSSf+3cu5ruZk1lvh6cN+E2+LMd/PcVgG0=",
      "url": "_framework/System.Net.Primitives.bg60hpoftx.wasm"
    },
    {
      "hash": "sha256-ehngWpGsAjN7oFKwx8KgZjs92gCmY0Jc4g6E8EjrZh8=",
      "url": "_framework/System.ObjectModel.65gbfd7zt9.wasm"
    },
    {
      "hash": "sha256-PgtMngktza42S5eLzdc0wUN1cgW2ifnmPzRoWBVlsTQ=",
      "url": "_framework/System.Private.CoreLib.egj3itakk4.wasm"
    },
    {
      "hash": "sha256-cNPugCJWc5ipDFM7rO/0TM1IwVR63tkroWH30LP4DXA=",
      "url": "_framework/System.Private.Uri.goqqz02kmb.wasm"
    },
    {
      "hash": "sha256-+FPqr17Knp1H2hpKNby8FpmP4wggzaSiBk9SDEOGeHo=",
      "url": "_framework/System.Private.Xml.Linq.cbeuw0p4v4.wasm"
    },
    {
      "hash": "sha256-e5iBRcRD7shEsW8UHehbiyXTmfwokb8mXzzPchx3yxk=",
      "url": "_framework/System.Private.Xml.fnzste8tvj.wasm"
    },
    {
      "hash": "sha256-nCbblFEi/RPu7nA+tVMIGyvX3hnETnnf95MSU1zIuyY=",
      "url": "_framework/System.Runtime.0xg3pmtra2.wasm"
    },
    {
      "hash": "sha256-krYk4OClLTGYToaMRQWFKxG7Y6GfR8ZSzmMKPlk5GK0=",
      "url": "_framework/System.Runtime.InteropServices.2bqtvcvkka.wasm"
    },
    {
      "hash": "sha256-Cjdb0G7x7YHp1aN8K34JIjyB6iQIEsmMfoZJJ71ZuOw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.mwa725m7o8.wasm"
    },
    {
      "hash": "sha256-DXqVdslzyf40ovcCo+rW1C7FnMDDjmKuNV+k01b0MR8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.1nx7g9wstq.wasm"
    },
    {
      "hash": "sha256-0yyv+YvzI7Om6Quzaf+SuAVGZFGmfjdUWJOz4/Xy9iE=",
      "url": "_framework/System.Security.Cryptography.99yv0p1k0h.wasm"
    },
    {
      "hash": "sha256-fTvzHBiEFaEyxnljXp/6CFyI/L6M+U4wwbUx/elCJEI=",
      "url": "_framework/System.Text.Encoding.CodePages.lm5sk7e5u7.wasm"
    },
    {
      "hash": "sha256-KqqWRjKnEB6AfDVf3rm0/MCd7SXbSGKyKpcY/+zEjSA=",
      "url": "_framework/System.Text.Encodings.Web.6kgc70ln9c.wasm"
    },
    {
      "hash": "sha256-JDgbpuUdf4VyOuWrWIMxvCSy9HQaSDZEkLoZrBrYrw4=",
      "url": "_framework/System.Text.Json.w98d9dhb4g.wasm"
    },
    {
      "hash": "sha256-6Y80wneOOG7292/xCcTJJG1Sh9xXZopXMIpW5WF++wM=",
      "url": "_framework/System.Text.RegularExpressions.z1hrtth0ol.wasm"
    },
    {
      "hash": "sha256-/kRMLvsHkM07aOOtmqVnyvgKfCaE8fQnBduMRan14m8=",
      "url": "_framework/System.Threading.62vn494vzb.wasm"
    },
    {
      "hash": "sha256-uqTBZOo4NXqcA+PEM9IrJIG538oEMABYLOrIfApz7VM=",
      "url": "_framework/System.Threading.Tasks.Parallel.um1co8pwdf.wasm"
    },
    {
      "hash": "sha256-R9FktnaduRAvMaZfcRZAXAs4UUQFRWQ+IzNgO/1vj8I=",
      "url": "_framework/System.Xml.Linq.no17d80mwx.wasm"
    },
    {
      "hash": "sha256-4OAniGStx78v5hRLPLSX1je6zJoKJ5LJe1h+hSF4XuE=",
      "url": "_framework/System.Xml.XDocument.472jj33lr0.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-BrqtZzkSjFtM8eaE8FmILWDhswSAdJEBgC62x+t+xK8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-wIjtmuRE6kzZLqwOFuophhaG28KcFPFi2IzM0GCvVDU=",
      "url": "_framework/dotnet.native.sxs7dfed8b.wasm"
    },
    {
      "hash": "sha256-64Fwln/2RyKgowRnj46XyGY/0yo3Os+A4qKy3KymxiE=",
      "url": "_framework/dotnet.native.xxtawia21s.js"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-EHu/EvCsJ6LBB7sYYqnIra6YTusflc8wSZDUZ8+LpvY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-exc9c7hTV9Cb+BfpfOnzSGiWhJQKk7BQsHi5jd7ZSzo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-W7ak/EGNO8IPTZEi16+5tI2xfeN8N3lFJLAiHA1H08E=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-ss3r+BvJXpL5Qr6jhPQMRnqZV/AIjR7HgcvvrPKwQBw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-h5KyEjypfLUc0eJEFykuY82A7M4fHWTtoc82u3Gy1rg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Tx7yA40PfJ+TqdDnvsSixbEWfqq1E1T/C9W8u5RRU8E=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-0/61oxM4YQby9pLbfu1U1mBZWm7PUjKU9yc8Z1xBMKQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-EyW2KiwsyOfqLLehwJ6tDKhFUNeXILxbENf+uVUFyxY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Mz8HMThzol5EonvCxgnhLTY0+eiDcpyQ18rn647ZlSE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-Nblnm9Fxa4q/m+kgbf2+9nvAbHdKuvCZpVj2iVBTGfQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-vSxd/IUU6SwSA5yx5lW38+boiLASbenB7zX9Rurh5AI=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-53VXXdN/GgBwqLtwN/EiiwQ7zKA2RzWry5na6Cu+BMA=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-a/Gbm1CCVHZJnJDEjuRi4DgflxwFuRQn7kzplj+n4iI=",
      "url": "professional-pic.jpg"
    }
  ]
};
